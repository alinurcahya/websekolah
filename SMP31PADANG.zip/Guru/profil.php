<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMP NEGERI 31 PADANG</title>
<link rel="stylesheet" href="css/style_content.css" type="text/css"/>
<link rel="stylesheet" href="css/style_table.css" type="text/css"/>
<link type="text/css" href="css/excite-bike/jquery-ui-1.8.21.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.21.custom.min.js"></script>
<!-- untuk menu superfish -->
<link rel="stylesheet" href="css/superfish.css" type="text/css" />
<script type="text/javascript" src="js/superfish.js"></script>
<!-- untuk mask -->
<script type="text/javascript" src="js/jquery.maskedinput.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	   $('ul.sf-menu').superfish();
  });
</script>
</head>
<body>
<div class="box">
<div class="border">
<div class="style">
	<div class="header">
    	<span class="title">
        	<div align="center">
        		<img src="images/SMPNegeri31Padang.png" width="1200" height="150" />
            </div>
        </span>
    </div>
	</br>
	<!--awal content -->
	<br>
<center><h1>PROFIL </h1></center>
<h2><center>A. Identitas Sekolah</center></h2>	
<h2><center>Nama Sekolah		: SMP NEGERI 31 PADANG</center></h2>
<h2><center>NPSN / NSS			: 10303491 / 201086105031</center></h2>
<h2><center>Jenjang Pendidikan	: SMP</center></h2>
<h2><center>Status Sekolah		: Negeri</center></h2>
</br>
<br>
<h2><center>B. Lokasi Sekolah</center></h2>
<h2><center>Alamat			: Jl. Andalas No. 126 Padang</center></h2>
<h2><center>RT/RW			: 1/4</center></h2>
<h2><center>Nama Dusun		: -</center></h2>
<h2><center>Desa/Kelurahan	: Andalas</center></h2>
<h2><center>Kode pos		: 25126</center></h2>
<h2><center>Kecamatan		: Kec. Padang Timur</center></h2>
<h2><center>Lintang/Bujur	: -0.9380000/100.3865000</center></h2>
</br>
<br>
<h2><center>C. Data Pelengkap Sekolah</center></h2>	
<h2><center>Kebutuhan Khusus		: -</center></h2>
<h2><center>SK Pendirian Sekolah	: 067/O/1994</center></h2>
<h2><center>Tgl SK Pendirian		: 1994-04-02</center></h2>
<h2><center>Status Kepemilikan		: Pemerintah Daerah</center></h2>
<h2><center>SK Izin Operasional		: 067/O/1994</center></h2>
<h2><center>Tgl SK Izin Operasional	: 1994-04-02</center></h2>
<h2><center>SK Akreditasi			: -</center></h2>
<h2><center>Tgl SK Akreditasi		: 2013-01-01</center></h2>
<h2><center>No Rekening BOS			: 1000.0210.02265-8</center></h2>
<h2><center>Nama Bank				: BANK NAGARI</center></h2>
<h2><center>Cabang / KCP Unit		: PASAR RAYA</center></h2>
<h2><center>Rekening Atas Nama		: SMP NEGERI 31 PADANG</center></h2>
<h2><center>MBS						: Ya</center></h2>
<h2><center>Luas Tanah Milik		: 7537 m2</center></h2>
<h2><center>Luas Tanah Bukan Milik	: 0 m2</center></h2>
</br>
<br>
<h2><center>D. Kontak Sekolah</h4>
<h2><center>Nomor Telepon			: 0751 - 39286</center></h2>
<h2><center>Nomor Fax				: -</center></h2>
<h2><center>Email					: smp31padang@yahoo.co.id</center></h2>
<h2><center>Website					: http://smpn31padang.sch.id/</center><h2>
</br>
<br>
<h2><center>E. Data Periodik</h2>
<h2><center>Kategori Wilayah		: -</center></h2>
<h2><center>Daya Listrik			: 15200</center></h2>
<h2><center>Akses Internet			: Telkom Speedy</center></h2>
<h2><center>Akreditasi				: B</center></h2>
<h2><center>Waktu Penyelenggaraan	: Pagi</center></h2>
<h2><center>Sumber Listrik			: PLN</center></h2>
<h2><center>Sertifikasi ISO			: Belum Bersertifikat</center></h2>
</br>
<div class="col-md-2">

	<div id="connect">
					<a href="http://pinterest.com/fwtemplates/" target="_blank" class="pinterest"></a> <a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" class="facebook"></a> <a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" class="twitter"></a> <a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" class="googleplus"></a>
				</div>
	
    <!--akhir content -->
    <div class="footer" align="center">
    	<p>CREATED BY @ WIDYA SAFITRI </p>
    </div>
</div>
</div>
</div>
</body>
</html>
</html>