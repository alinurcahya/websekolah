<?php
include "./Config/koneksi.php";
?>

	<div align="center">
	<h2><a href="#">Selamat Datang di Sistem Informasi Akademik Sekolah</a></h2>
	<p><?php echo date("H:m:s, d F Y") ?></p>
	<p>Anda sedang berada di halaman Sistem Informasi Jadwal Akademik SMP NEGERI 31 PADANG.</p><br />
	<p> <img src="./images/logo.gif"></p>
	</div>
	
	
	