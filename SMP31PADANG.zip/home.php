<?php
include "../include/config.php";
//Copyright © 2016 KHAIRUNNISA SAMOSIR
?>
<div style="color:#618C04">
	<div align="center">
	<h2><blink>Selamat Datang di Sistem Informasi Akademik Sekolah</blink></h2>
	<p><?php echo date("H:m:s, d F Y") ?></p>
	<p> <img src="../admin/images/logo.GIF"></p>
    <br />
	</div>
</div>