<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMP NEGERI 31 PADANG</title>
<link rel="stylesheet" href="css/style_content.css" type="text/css"/>
<link rel="stylesheet" href="css/style_table.css" type="text/css"/>
<link type="text/css" href="css/excite-bike/jquery-ui-1.8.21.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.21.custom.min.js"></script>
<!-- untuk menu superfish -->
<link rel="stylesheet" href="css/superfish.css" type="text/css" />
<script type="text/javascript" src="js/superfish.js"></script>
<!-- untuk mask -->
<script type="text/javascript" src="js/jquery.maskedinput.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	   $('ul.sf-menu').superfish();
  });
</script>
</head>
<body>
<div class="box">
<div class="border">
<div class="style">
	<div class="header">
    	<span class="title">
        	<div align="center">
        		<img src="images/SMPNegeri31Padang.png" width="840" height="150" />
            </div>
        </span>
    </div>
	</br>
	<!--awal content -->
	<li>
	<a href="galery.php"></a>
	</li>
	<div id="contents">
				
	<h1><center>"Documentation Fhoto SMPN 31 Padang"</center></h1>
        <br>
<br>
<br>                    
	<ul id="rooms">
					<marquee onmouseout='this.start()' onmouseover='this.stop()' direction="left" height="30%" width="80%">
<div id="GALERI">
<td>
<img src="../images/guru.jpg"height="250" width="300">
</td>
<td>
<img src="../images/8a.jpg"height="250" width="300">
</td>
<td>
<img src="../images/13a.jpg"height="250" width="300">
</td>
<img src="../images/IMG_4154.jpg"height="250" width="300">
<img src="../images/siswa.jpg"height="250" width="300">
<img src="../images/siswa1.jpg"height="250" width="300">
<img src="../images/smp1.jpg"height="250" width="300">
<img src="../images/smp.jpg"height="250" width="300">
<img src="../images/picture-127.jpg"height="250" width="300">
<img src="../images/foto2.jpg"height="250" width="300">
</div>
 </marquee> 			
                            <br>
<br>
<br>

<br>
<br>
<br>
<br>							
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>

<div class="col-md-2">
	
    <!--akhir content -->
    <div class="footer" align="center">
    	<p>CREATED BY @ WIDYA SAFITRI </p>
    </div>
</div>
</div>
</div>
</body>
</html>