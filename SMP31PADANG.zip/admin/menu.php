<ul class="sf-menu">
<center>
<li><a href="media.php">Home</a></li>	
<li>

<li><a href="profil.php">Profil</a></li>
<li><a href="input_guru.php">Entry Data Guru</a></li>
<li><a href="input_hari.php">Entry Data Hari</a></li>

<li><a href="input_jabatan.php">Entry Jabatan</a></li>


<li>
<a href="#">Laporan</a>
<ul>
<li><a href="view_guru.php">guru</a></li>
<li><a href="view_hari.php">hari</a></li>
<li><a href="view_jabatan.php">jabatan</a></li>
</ul>
</li>
<li><a href="logout.php">Log Out</a></li>
</ul>