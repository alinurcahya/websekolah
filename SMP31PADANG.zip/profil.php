<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SMP NEGERI 31 PADANG</title>
<link rel="stylesheet" href="css/style_content.css" type="text/css"/>
<link rel="stylesheet" href="css/style_table.css" type="text/css"/>
<link type="text/css" href="css/excite-bike/jquery-ui-1.8.21.custom.css" rel="stylesheet" />	
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.21.custom.min.js"></script>
<!-- untuk menu superfish -->
<link rel="stylesheet" href="css/superfish.css" type="text/css" />
<script type="text/javascript" src="js/superfish.js"></script>
<!-- untuk mask -->
<script type="text/javascript" src="js/jquery.maskedinput.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	   $('ul.sf-menu').superfish();
  });
</script>
</head>
<body>
<div class="box">
<div class="border">
<div class="style">
	<div class="header">
    	<span class="title">
        	<div align="center">
        		<img src="images/aa.jpeg" width="840" height="120" />
            </div>
        </span>
    </div>
	</br>
	<div class="index">
   	 	<?php include 'index.php'; ?>
    </div>
	<!--awal content -->
	</br>
<center><h3>VISI</h3></center>
<h4>Dalam mendukung Visi Pemerintahan Kota Padang, Dinas Pendidikan sebagai perangkat daerah menetapkan visi yang berkaitan dengan pendidikan adalah sebagai berikut :

"Terwujudnya Pendidikan yang Unggul, Berdaya Saing, Kreatif dan Beriman"</h4>
</br>
<center><h3>MISI</h3></center>
<h4>Meningkatkan ketersediaan dan keterjangkauan layanan pendidikan.<h4>
<h4>Meningkatkan kualitas pendidik dan tenaga kependidikan.</h4>
<h4>Mengupayakan agar tenaga listrik menjadi pendorong kegiatan ekonomi.</h4>
<h4>Mewujudkan terselenggaranya proses pembelajaran yang kreatif, inovatif dan berakhlak mulia.</h4>

<div class="col-md-2">
	
    <!--akhir content -->
    <div class="footer" align="center">
    	<p>Created By Khairunnisa Samosir </p>
    </div>
</div>
</div>
</div>
</body>
</html>