<?php
include "../../include/conf_user.php";

//$_SESSION=array();
unset($_SESSION['user']);
unset($_SESSION['hak']);
//setcookie('PHPSESSID','',time()-3600,'/','',0);
?>
<script>document.location.href="../"</script>