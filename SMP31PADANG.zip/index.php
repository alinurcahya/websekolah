<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>SISTEM INFORMASI AKADEMIK JADWAL PELAJARAN SMP NEGERI 31 PADANG</title>
</head>
<body background="bg.png">
<div>
  <h2 style="text-align:center; background-image:url(header.png);color:#000066;padding-bottom:5px;padding-top:5px;font-family:Arial, Helvetica, sans-serif">SELAMAT DATANG DI SISTEM INFORMASI JADWAL PELAJARAN SMP NEGERI 31 PADANG</h2>
</div>
<div style="padding-top:20px;">
<h1 style="font-family:Arial, Helvetica, sans-serif;color:#000066;" align="center">-== MENU LOGIN UTAMA ==-</h1>
<table width="618" height="285" border="0" align="center" >
  <tr align="center">
    <td width="256"><a href="admin/login.php"><img src="icon/adm.png" width="200" height="200" border="0"><h3 style="font-family:Arial, Helvetica, sans-serif">Login Admin</h3></a></td>
    <td width="105">&nbsp;</td>
    <td width="243"><a href="Guru/login.php"><img src="icon/guru.png" width="200" height="200" border="0"><h3 style="font-family:Arial, Helvetica, sans-serif">Login Guru</h3></a></td>
	<td width="105">&nbsp;</td>
	<td width="243"><a href="Siswa/login.php"><img src="icon/studen.png" width="200" height="200" border="0"><h3 style="font-family:Arial, Helvetica, sans-serif">Login Siswa</h3></a></td>
  </tr>
</table></div>
<div>
<h4 align="center" style="background-color:#FFFFFF;color:#000066;padding-bottom:5px;padding-top:5px;font-family:Arial, Helvetica, sans-serif;"><blink>Login Admin untuk Login Administrator..&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp; Login Guru untuk Login Guru...||&nbsp;&nbsp;&nbsp; Login Siswa untuk Login Siswa...</blink></h4>
</div>
<center><font face="Arial, Helvetica, sans-serif" size="-2">Sistem Informasi Akademik JADWAL PELAJARAN SMP NEGERI 31 PADANG &copy; 2016 by <a href="http://samosir.5gfree.com" target="_blank">WIDYA SAFITRI</a><br /> MAHASISWA UNIVERSITAS PUTRA INDONESIA YPTK PADANG
</font>
</center>
</body>
</html>
